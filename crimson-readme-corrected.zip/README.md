<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&height=235&color=0:18030a,45:7f101b,100:09090d&text=RAHUL%20RAMAMOORTHY&fontColor=ffffff&fontSize=38&fontAlignY=39&animation=fadeIn&desc=Software%20Engineer%20%7C%20Competitive%20Programmer%20%7C%20AI%20Explorer&descSize=15&descAlignY=62" width="100%" alt="Rahul Ramamoorthy crimson banner" />

<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&weight=600&size=22&duration=2800&pause=900&color=FF4655&center=true&vCenter=true&width=780&lines=Building+things+that+solve+real+problems;SIH+2025+Champion+%7C+CSIC+Finalist;Full+Stack+%E2%80%A2+AI%2FML+%E2%80%A2+Distributed+Systems;Always+learning.+Always+building." alt="Animated typing introduction" /></a>

[![GitHub](https://img.shields.io/badge/GitHub-0D1117?style=for-the-badge&logo=github&logoColor=white)](https://github.com/rahul14rx)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-A41424?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/rahul-ramamoorthy-38225a284/)
[![Email](https://img.shields.io/badge/Email-6B0F1A?style=for-the-badge&logo=gmail&logoColor=white)](mailto:rdrahul2005@gmail.com)

</div>

## `01 / About me`

I'm Rahul, a **Computer Science undergraduate at Chennai Institute of Technology**, graduating in **2027**.

I enjoy turning complicated ideas into useful software — from algorithms and distributed systems to AI-powered applications.

**Exploring:** AI/ML, backend engineering, cybersecurity, and distributed systems.  
**Outside code:** Painting and playing the keyboard.

## `02 / Competitive programming`

<div align="center">

### 🟡 LeetCode

**Guardian**  
[rahulrnewr](https://leetcode.com/u/rahulrnewr/)

### ⭐ CodeChef

**⭐ ⭐ ⭐ ⭐ ⭐**  
[rdrahul2005](https://www.codechef.com/users/rdrahul2005)

### 🔵 Codeforces

![EXPERT](https://img.shields.io/badge/EXPERT-173B79?style=for-the-badge&labelColor=173B79&color=173B79)  
[RahulR_](https://codeforces.com/profile/RahulR_)

</div>

## `03 / Highlights`

- 🏆 **Smart India Hackathon 2025 Champion** — Software Edition.
- 🥇 **Golden Coders 2023 Winner** — Middle East.
- 🚀 **CSIC Finalist**.
- 💼 **CRIS / Indian Railways** software engineering intern.
- 🔬 **NIT Puducherry** research intern.

<div align="center">
<img src="assets/achievements.png" width="95%" alt="Achievements: SIH 2025 Champion, Golden Coders Winner, CSIC Finalist" />
</div>

## `04 / What I've built`

<!-- Crimson table is an SVG image because GitHub removes background colors from HTML tables. -->
<div align="center">
<img src="assets/project-table-crimson.svg" width="100%" alt="Crimson table of six featured projects and descriptions" />
</div>

**Project repositories:** 🇮🇳 [Nyay Sahayak](https://github.com/rahul14rx/sih_winner_loan) · 🗄️ [VaultDB](https://github.com/rahul14rx/VaultDB-Distributed-SQL-Engine) · 🧩 [OASIS](https://github.com/n1shanthb/OASIS) · 🛡️ [Raksha](https://github.com/rahul14rx/raksha-backend) · 🔐 [Qumail](https://github.com/rahul14rx/qumail) · 🏠 [AI Blueprint](https://github.com/rahul14rx/ai_blueprint)

[Explore all repositories →](https://github.com/rahul14rx?tab=repositories)

## `05 / The stack`

<div align="center">

![Python](https://img.shields.io/badge/Python-1B1B23?style=for-the-badge&logo=python&logoColor=FF4655)
![Java](https://img.shields.io/badge/Java-1B1B23?style=for-the-badge&logo=openjdk&logoColor=FF4655)
![C++](https://img.shields.io/badge/C++-1B1B23?style=for-the-badge&logo=cplusplus&logoColor=FF4655)
![TypeScript](https://img.shields.io/badge/TypeScript-1B1B23?style=for-the-badge&logo=typescript&logoColor=FF4655)
![React](https://img.shields.io/badge/React-1B1B23?style=for-the-badge&logo=react&logoColor=FF4655)
![Next.js](https://img.shields.io/badge/Next.js-1B1B23?style=for-the-badge&logo=nextdotjs&logoColor=FF4655)
![Node.js](https://img.shields.io/badge/Node.js-1B1B23?style=for-the-badge&logo=nodedotjs&logoColor=FF4655)
![FastAPI](https://img.shields.io/badge/FastAPI-1B1B23?style=for-the-badge&logo=fastapi&logoColor=FF4655)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-1B1B23?style=for-the-badge&logo=postgresql&logoColor=FF4655)
![MongoDB](https://img.shields.io/badge/MongoDB-1B1B23?style=for-the-badge&logo=mongodb&logoColor=FF4655)
![TensorFlow](https://img.shields.io/badge/TensorFlow-1B1B23?style=for-the-badge&logo=tensorflow&logoColor=FF4655)
![Git](https://img.shields.io/badge/Git-1B1B23?style=for-the-badge&logo=git&logoColor=FF4655)

</div>

## `06 / Experience`

<div align="center">
<img src="assets/career-route.png" width="95%" alt="Career path across Resh and Thosh, KaarTech, NIT Puducherry and Indian Railways" />
</div>

| Where | Work |
|:--|:--|
| **CRIS / Ministry of Railways** · 2026 | Software engineering internship; continued building OASIS afterward. |
| **NIT Puducherry** · 2025 | Research internship on Tamil medical question answering and reinforcement learning. |
| **KaarTech Technologies** · 2025 | Full-stack development for the KEBS Help Center. |
| **Resh and Thosh** | Earlier software development internship. |

## `07 / Developer activity`

<div align="center">
<img src="https://github-readme-stats.vercel.app/api?username=rahul14rx&show_icons=true&hide_border=true&bg_color=0D1117&title_color=FF4655&text_color=F1F5F9&icon_color=FF4655" height="165" alt="Rahul GitHub stats" />
<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=rahul14rx&layout=compact&hide_border=true&bg_color=0D1117&title_color=FF4655&text_color=F1F5F9" height="165" alt="Most-used GitHub languages" />
</div>

### 🐍 Crimson contribution snake

<div align="center">
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/rahul14rx/rahul14rx/output/github-contribution-grid-snake-dark.svg" />
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/rahul14rx/rahul14rx/output/github-contribution-grid-snake.svg" />
  <img alt="Animated red snake eating GitHub contributions" src="https://raw.githubusercontent.com/rahul14rx/rahul14rx/output/github-contribution-grid-snake.svg" width="100%" />
</picture>
</div>

<sub>The snake is generated from my actual contribution graph and refreshes automatically.</sub>

---

<div align="center">

**The best part of building something is finding out what it can become.**

<img src="https://capsule-render.vercel.app/api?type=waving&height=110&section=footer&color=0:09090d,50:7f101b,100:18030a" width="100%" alt="Crimson footer" />

</div>
